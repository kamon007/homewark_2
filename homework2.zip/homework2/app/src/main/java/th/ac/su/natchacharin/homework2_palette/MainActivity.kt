package th.ac.su.natchacharin.homework2_palette

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn_a = findViewById<Button>(R.id.btn_a)
        var btn_b = findViewById<Button>(R.id.btn_b)
        var btn_c = findViewById<Button>(R.id.btn_c)
        var btn_d = findViewById<Button>(R.id.btn_d)
        var btn_e = findViewById<Button>(R.id.btn_e)
        var btn_f = findViewById<Button>(R.id.btn_f)

        val showColor = findViewById<TextView>(R.id.rgb_code)

        btn_a.setOnClickListener(){
            showColor.setBackgroundColor(Color.parseColor("#EBE1DE"));
            showColor.text = "235-225-222"
        }

        btn_b.setOnClickListener(){
            showColor.setBackgroundColor(Color.parseColor("#ECCBCA"));
            showColor.text = "236-203-202"
        }
        btn_c.setOnClickListener(){
            showColor.setBackgroundColor(Color.parseColor("#75839C"));
            showColor.text = "117-131-156"
        }
        btn_d.setOnClickListener(){
            showColor.setBackgroundColor(Color.parseColor("#99A9BF"));
            showColor.text = "153-169-191"
        }
        btn_e.setOnClickListener(){
            showColor.setBackgroundColor(Color.parseColor("#C2CCD5"));
            showColor.text = "194-204-213"
        }
        btn_f.setOnClickListener(){
            showColor.setBackgroundColor(Color.parseColor("#DDE2E5"));
            showColor.text = "221-226-229"
        }
    }
}